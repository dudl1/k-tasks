window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "1701765.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
window.SCRIPTS = [ 126949834, 126949836, 126949839, 126949840 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/126949828/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/126949829/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/126949827/1/ammo.js', 'preload' : true},
];
